package com.niteesh.ecommerce.user;

public class UsernameAlreadyExistsException extends RuntimeException {
    public UsernameAlreadyExistsException() { super("Username is already registered"); }
}
