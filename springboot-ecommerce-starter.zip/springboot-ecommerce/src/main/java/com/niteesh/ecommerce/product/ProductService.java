package com.niteesh.ecommerce.product;

import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ProductService {
    private final ProductRepository repository;

    public ProductService(ProductRepository repository) { this.repository = repository; }

    @Transactional(readOnly = true)
    public Page<Product> findAll(int page, int size) {
        int safeSize = Math.max(1, Math.min(size, 100));
        return repository.findAll(PageRequest.of(Math.max(page, 0), safeSize, Sort.by("id").descending()));
    }

    @Transactional(readOnly = true)
    public Product findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new ProductNotFoundException(id));
    }

    public Product create(ProductRequest request) {
        return repository.save(new Product(request.name().trim(), request.description(),
                request.price(), request.stockQuantity()));
    }

    public Product update(Long id, ProductRequest request) {
        Product product = findById(id);
        product.update(request.name().trim(), request.description(), request.price(), request.stockQuantity());
        return repository.save(product);
    }

    public void delete(Long id) {
        Product product = findById(id);
        repository.delete(product);
    }
}
