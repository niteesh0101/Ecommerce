package com.niteesh.ecommerce.user;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;

    public AuthController(AppUserRepository users, PasswordEncoder passwordEncoder) {
        this.users = users;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public Message register(@Valid @RequestBody RegisterRequest request) {
        String username = request.username().trim();
        if (users.existsByUsername(username)) {
            throw new UsernameAlreadyExistsException();
        }
        users.save(new AppUser(username, passwordEncoder.encode(request.password()), "ROLE_USER"));
        return new Message("Account created. Use HTTP Basic authentication with your username and password.");
    }

    public record Message(String message) {}
}
