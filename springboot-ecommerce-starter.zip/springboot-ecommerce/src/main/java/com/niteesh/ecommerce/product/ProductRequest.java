package com.niteesh.ecommerce.product;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public record ProductRequest(
    @NotBlank @Size(max = 120) String name,
    @Size(max = 2000) String description,
    @NotNull @DecimalMin(value = "0.00") @Digits(integer = 10, fraction = 2) BigDecimal price,
    @NotNull @Min(0) Integer stockQuantity
) {}
