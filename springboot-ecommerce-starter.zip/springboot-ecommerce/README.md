# Spring Boot E-Commerce API

A learning-focused REST API starter using Java 21, Spring Boot, Spring Security, Spring Data JPA, and MySQL. This project is intentionally separate from the existing Weather Forecast App files in the parent repository.

## Implemented in this starter

- Product create/read/update/delete endpoints
- Product input validation and pagination
- Database-backed user registration
- BCrypt password hashing
- Spring Security HTTP Basic authentication for protected write operations
- Consistent JSON errors for common validation and not-found cases
- Docker image and Docker Compose setup with persistent MySQL storage

## Not implemented yet

Shopping cart, checkout, order lifecycle, payment integration, JWT, admin-user provisioning, frontend, CI/CD, and production deployment hardening are follow-up milestones. This starter does not claim those features are ready.

## Requirements

- Java 21 and Maven, or Docker with Docker Compose
- MySQL 8.4 if running without Compose

## Run with Docker Compose

1. Copy `.env.example` to `.env`.
2. Replace both sample passwords with strong random values.
3. Run:

   ```bash
   docker compose up --build -d
   docker compose logs -f app
   ```

4. The API listens on `http://localhost:8080`.
5. Stop with `docker compose down`. The named `mysql-data` volume remains. To delete database data too, run `docker compose down -v` (destructive).

Do not expose MySQL publicly or commit `.env`.

## Run locally

Configure `DB_URL`, `DB_USERNAME`, and `DB_PASSWORD`, ensure the database exists, then run:

```bash
mvn spring-boot:run
```

## API endpoints

| Method | Path | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register a regular user |
| GET | `/api/products?page=0&size=20` | Public | List products |
| GET | `/api/products/{id}` | Public | Get one product |
| POST | `/api/products` | Authenticated | Create product |
| PUT | `/api/products/{id}` | Authenticated | Update product |
| DELETE | `/api/products/{id}` | Authenticated | Delete product |

Registration example:

```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"username":"demo-user","password":"replace-this-password"}'
```

After registering, use HTTP Basic auth for product write operations:

```bash
curl -u demo-user:replace-this-password \
  -H 'Content-Type: application/json' \
  -X POST http://localhost:8080/api/products \
  -d '{"name":"Keyboard","description":"Mechanical keyboard","price":2499.00,"stockQuantity":20}'
```

**Security note:** This starter permits any authenticated user to write products to keep the first learning milestone small. Before production, introduce roles, restrict product management to admins, enable appropriate CSRF protection if using cookies/sessions, configure TLS, and add rate limiting and audit logging. HTTP Basic should only be used over HTTPS outside local development.

## Deployment direction

The planned deployment target is AWS EC2 running Docker Compose. Before public deployment, use strong secrets, restrict inbound ports, expose only HTTP/HTTPS via a reverse proxy, configure TLS, backups, monitoring, and patching. For production-grade deployments, consider managed database hosting rather than keeping the database on the same VM.

## Repository context

When added to `niteesh0101/Ecommerce`, keep this project in a dedicated `springboot-ecommerce/` subdirectory so the existing root `index.html` and root `README.md` are preserved.
